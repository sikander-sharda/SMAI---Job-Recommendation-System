﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyProj.Model;
using System.Collections.ObjectModel;
using System.Windows.Input;
using MyProj.Command;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;

namespace MyProj.ViewModel
{
    public class PersonViewModel : INotifyPropertyChanged
    {

        void ReadFile()
        {
            string text2 = System.IO.File.ReadAllText(@"E:\file.txt");
            // string ln = "";
            var temp_da = text2.Split('\n');
            for (int i = 0; i < temp_da.Length - 1; i++)
            {
                var spdata = temp_da[i].Split('#');
                Patient temp_p = new Patient();
                temp_p.Fname = spdata[1]; temp_p.Id = spdata[0]; temp_p.Mobile = spdata[4];
                System.Console.WriteLine(temp_p.Fname + " " + temp_p.Id + " " + temp_p.Mobile);
                display_data.Add(temp_p);
                Patient_Record temp_pt = new Patient_Record();
                temp_pt.Fname = spdata[1]; temp_pt.Id = spdata[0]; temp_pt.Mobile = spdata[4];
                temp_pt.Lname = spdata[2]; temp_pt.DOB = spdata[5]; temp_pt.Email = spdata[3];
                main_data.Add(temp_pt);
            }
        }
        private bool checkDuplicate(string firstname, string lastname, string email, string mobile)
        {
            
                if (email.Length == 0)
                {
                    Error = "Enter an email.";
                    Console.WriteLine("fweeee");
                    return false;
                    //errormessage.Text = DateTime.Now.To;
                    //textBoxEmail.Focus();
                }


                if (!Regex.IsMatch(email, @"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"))
                {
                    Error = "Enter a valid email.";
                    return false;
                    //
                }
                if (mobile.Length == 0)
                {
                    Error = "Enter Mobile No.";
                    return false;
                }
                if (!Regex.IsMatch(mobile, @"^\d{10}$"))
                {
                    Error = "Enter a valid Mobile No.";
                    return false;
                }
                if (firstname.Length == 0 || lastname.Length == 0 || !Regex.IsMatch(firstname, @"^[A-Za-z]+$") || !Regex.IsMatch(lastname, @"^[A-Za-z]+$"))
                {
                    Error = "Enter a valid Name";
                    return false;
                }
           
                foreach (var p in main_data)
                {
                    if ((p.Email == email) && (p.Fname == firstname) && (p.Lname == lastname) && (p.Mobile == mobile))
                    {
                        Error = "User already Registered";
                        return false;
                    }
                }
                //Patient temp_p = new Patient
                Error = "So Far So Good";
                return true;
         
        }
        public PersonViewModel()
        {
            Error = "";
            PatientRecord_data = new Patient_Record { Email="", DOB="", Fname="", Id="", Lname="", Mobile=""};
            display_data = new ObservableCollection<Patient>();
            main_data = new List<Patient_Record>();
            ReadFile();
        }
        private string _error;
        public string Error
        {
            get { return _error; }
            set { _error = value; OnPropertyChanged("Error"); }
        }
        private Patient_Record _patient;
        public Patient_Record PatientRecord_data
        {
            get { return _patient; }
            set { _patient = value; OnPropertyChanged("PatientRecord_data"); }
        }

        /************************************************************************************************/

        private ObservableCollection<Patient> _display_data;
        private List<Patient_Record> _main_data;
        public List<Patient_Record> main_data
        {
            get { return _main_data; }
            set
            {
                _main_data = value;
                //OnPropertyChanged("display_data");
            }
        }
        public ObservableCollection<Patient> display_data
        {
            get { return _display_data; }
            set
            {
                _display_data = value;
                OnPropertyChanged("display_data");
            }
        }

        /*************************************************************************************************/

        private ICommand _AddCommand;
        public ICommand AddCommand
        {
            get
            {
                if (_AddCommand == null)
                {
                    _AddCommand = new RelayCommand(AddExecute, CanAddExecute , true);
                }
                return _AddCommand;
            }
        }

        private void AddExecute(object parameter)
        {
            //Person obj = new Person();
            PatientRecord_data.Id = DateTime.Now.ToString("ddMMyyyyHHmmss");
            main_data.Add(PatientRecord_data);
            Patient temp_p = new Patient();
            temp_p.Fname = PatientRecord_data.Fname;
            temp_p.Mobile = PatientRecord_data.Mobile;
            temp_p.Id = PatientRecord_data.Id;
            display_data.Add(temp_p);
            string str = PatientRecord_data.Id + "#" + PatientRecord_data.Fname + "#" + PatientRecord_data.Lname + "#" + PatientRecord_data.Email + "#" + PatientRecord_data.Mobile + "#" + PatientRecord_data.DOB;
            File.AppendAllText(@"E:\file.txt", str + Environment.NewLine);
            Error = "Registered Successfully!";
            //Thread.Sleep(1000); 
        }

        

        private bool CanAddExecute(object parameter)
        {
            if(PatientRecord_data.Email=="")Console.WriteLine("Asd");
            
            
                if (checkDuplicate(PatientRecord_data.Fname, PatientRecord_data.Lname, PatientRecord_data.Email, PatientRecord_data.Mobile))
                    return true;
                else
                    return false;

        }

        /***************************************************************************************************/


        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

    }
}
