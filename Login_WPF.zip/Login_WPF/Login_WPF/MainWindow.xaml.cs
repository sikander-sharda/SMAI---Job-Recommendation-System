﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.IO;
//using XmlHelper;


namespace Login_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    
    //For displaying in DataGrid and Checking Dups
    public class Patient
    {
        public string ID { get; set; }
        public string FName {get; set;}
        public string Mobile { get; set; }

        public string Email { get; set; }
    }
    public class Patient_Record
    {
        public string ID { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string DOB { get; set; }

    }
    public class Patient_Records
    {
        public List<Patient_Record> pt { get; set; }

        public Patient_Records()
        {
            pt = null;
        }
       /* public void Add(Patient_Record ptt)
        {
            pt.Add(ptt);
        }*/
    }
    public partial class MainWindow : Window
    {
        String str;
        List<Patient> display_data = new List<Patient>();
        Patient_Records main_data = new Patient_Records();
        public MainWindow()
        {

            InitializeComponent();
            readFile();
            dataGrid1.ItemsSource = LoadData();
        }
        private void readFile()
        {
            return;
            string text = System.IO.File.ReadAllText(@"C:\Users\Corleone\Documents\SMAI---Job-Recommendation-System-master\Login_WPF\file.txt");
            string ln = "";
            foreach(var ch in text)
            {
                //System.Console.Write(ch);
                if(ch=='\n')
                {
                    //data.Add(ln);
                    System.Console.Write(ln);
                    ln = "";
                }
                else
                {
                    ln += ch;
                }
            }
        }
        private int checkDuplicate(Patient checkp)
        {
            //Patient temp = null;
            foreach(Patient temp2 in display_data)
            {
                if (checkp.Mobile == temp2.Mobile && checkp.Email == temp2.Email && checkp.FName == temp2.FName)
                    return 0;
            }
            return 1;
        }

        //For DataGrid Display
        private List<Patient> LoadData()
        {
            List<Patient> patients = new List<Patient>();
            
                foreach (Patient s in display_data)
                {

                    //var spdata = s.Split('#');
                    patients.Add(new Patient()
                        {
                            ID = s.ID,
                            FName = s.FName,
                            Email = s.Email,
                            Mobile = s.Mobile,

                        });

                }
           
            
            return patients;
        }
        private void button2_Click(object sender, RoutedEventArgs e)
        {
            Reset();
        }

        private void Reset()
        {
            textBoxFirstName.Text = "";
            textBoxLastName.Text = "";
            textBoxEmail.Text = "";
            textBoxAddress.Text = "";
            textBoxMobile.Text = "";
            dateP.Text = "";
            
        }
        private void dataGrid1_SelectionChanged(object sender, EventArgs e)
        {
            Patient sel = (Patient)dataGrid1.SelectedItem;
            string text = System.IO.File.ReadAllText(@"C:\Users\sikander.s1\Documents\Visual Studio 2013\Projects\Samsung_practice\file.txt");
            //sel.ID
            textBoxFirstName.Text = "";
            textBoxLastName.Text = "";
            textBoxEmail.Text = "";
            textBoxAddress.Text = "";
            textBoxMobile.Text = "";
            dateP.Text = "";
        }
        private void button3_Click(object sender, RoutedEventArgs e)
        {
            Patient sel = (Patient)dataGrid1.SelectedItem;
            System.Console.WriteLine(sel.FName);
        }






        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            if (textBoxEmail.Text.Length == 0)
            {
                errormessage.Text = "Enter an email.";
                //errormessage.Text = DateTime.Now.To;
                textBoxEmail.Focus();
            }
            else if (!Regex.IsMatch(textBoxEmail.Text, @"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"))
            {
                errormessage.Text = "Enter a valid email.";
                textBoxEmail.Select(0, textBoxEmail.Text.Length);
                textBoxEmail.Focus();
            }
            else
            {
                string firstname = textBoxFirstName.Text;
                string lastname = textBoxLastName.Text;
                string email = textBoxEmail.Text;
                string mobile = textBoxMobile.Text;
                if (textBoxMobile.Text.Length == 0)
                {
                    errormessage.Text = "Enter Mobile No.";
                    textBoxMobile.Focus();
                }
                else if (!Regex.IsMatch(textBoxMobile.Text, @"^\d{10}$"))
                {
                    errormessage.Text = "Enter a valid Mobile No.";
                    textBoxMobile.Focus();
                }
                else
                {
                    if(firstname.Length == 0||lastname.Length == 0 || !Regex.IsMatch(firstname, @"^[A-Za-z]+$")||!Regex.IsMatch(lastname, @"^[A-Za-z]+$"))
                    {
                        errormessage.Text = "Enter a valid Name";
                        textBoxFirstName.Focus();
                        textBoxLastName.Focus();
                    }
                    else
                    {
                        errormessage.Text = "";
                        string address = textBoxAddress.Text;
                        //str = firstname + "#" + lastname + "#" + email + "#" + mobile;
                        Patient checkp = new Patient();
                        checkp.Email = email; checkp.FName = firstname; checkp.Mobile = mobile;
                        checkp.ID = DateTime.Now.ToString("yyyyMMddHHmmss");

                        //string id = DateTime.Now.ToString();

                        if (checkDuplicate(checkp) == 0)
                        {
                            errormessage.Text = "User already registered";
                        }
                        else
                        {
                            System.Console.WriteLine("ASDASD\n");
                            //string id = DateTime.Now.ToString("yyyyMMddHHmmss");
                            
                            //str = id + "#" + firstname + "#" + lastname + "#" + email + "#" + mobile + "#" + dateP;
                            Patient_Record ptt = new Patient_Record();
                            ptt.ID = checkp.ID; ptt.Email = checkp.Email;
                            ptt.FName = firstname; ptt.Mobile = mobile;
                            ptt.LName = lastname; ptt.DOB = dateP.ToString();
                            main_data.pt.Add(ptt);
                            //Patient_Records prs = new Patient_Records();
                            //prs = main_data;
                            display_data.Add(checkp);
                            dataGrid1.ItemsSource = LoadData();
                            //File.AppendAllText(@"C:\Users\Corleone\Documents\SMAI---Job-Recommendation-System-master\Login_WPF\file.txt", str + Environment.NewLine);
                            XmlHelper objx = new XmlHelper();
                            objx.ToXmlFile(main_data, @"C:\Users\Corleone\Documents\SMAI---Job-Recommendation-System-master\Login_WPF\data.xml");
                            errormessage.Text = "You have Registered successfully.";

                            
                            Reset();
                        }
                    }
                }
            }
        }

       






        private void dataGrid1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
