﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace MyProj.Model
{
    public class Person  //notify to UI
    {
        private string fname, lname, fullname;

        public String Fname
        {
            get
            { return fname; }
            set
            {
                fname = value;
                //OnPropertyChanged(Fname);
            }
        }

        public String Lname
        {
            get
            { return lname; }
            set
            {
                lname = value;
                //OnPropertyChanged(Lname);
            }
        }

        public String FullName
        {
            get
            { return fullname = Fname + " " + Lname; }
            set
            {
                if (fullname != value)
                    fullname = value;
            }
        }

        //public event PropertyChangedEventHandler PropertyChanged;
        //private void OnPropertyChanged(string p)
        //{
        //    PropertyChangedEventHandler ph = PropertyChanged;
        //    if (ph != null)
        //        ph(this, new PropertyChangedEventArgs(p));
        //}
    }
}
